package com.controller;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ust.pms.model.Product;

@RestController
@RequestMapping("/anothermicroservice")
public class MyRestController {
	URI uri = URI.create("http://localhost:9090/getDataFromCloud");
	URI producturi = URI.create("http://localhost:8085/product");
	@Autowired
	RestTemplate restTemplate;

	@RequestMapping("/hi")
	public ResponseEntity<String> hi() {
		ResponseEntity<String> response = restTemplate.getForEntity(uri, String.class);
		return response;
	}

	@GetMapping
	public List<Product> getProducts() {
		ResponseEntity<Product[]> response = restTemplate.getForEntity(producturi, Product[].class);
		return Arrays.asList(response.getBody());
	}

	@PostMapping
	public ResponseEntity<Product> saveProduct(@RequestBody Product product) {
		ResponseEntity<Product> response = restTemplate.getForEntity(producturi, Product.class);
		return response;
	}

	@PutMapping
	public ResponseEntity<Product> updateProduct(@RequestBody Product product) {
		ResponseEntity<Product> response = restTemplate.getForEntity(producturi, Product.class);
		return response;
	}

	/*
	 * @DeleteMapping(path = "/{productId}") public ResponseEntity<Product>
	 * deleteProduct(@PathVariable("productId") Integer productId) {
	 * 
	 * ResponseEntity<Product> response=restTemplate.getForEntity(producturi,
	 * Product.class); return response; }
	 */
	@DeleteMapping("/{productId}")
	public String deleteProduct(@PathVariable("productId") Integer productId) {
		String PId = productId.toString();
		restTemplate.delete(producturi + "/" + PId);
		return "data deleted successfully";

	}
}
