package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MyBackEndService {
	
public String getData() {
	/*
	 * try { Thread.sleep(10000); }catch(InterruptedException e) {
	 * e.printStackTrace(); }
	 */
	return "This msg is from backend service";
}
}
